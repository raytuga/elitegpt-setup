#!/bin/bash

set -e
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${GREEN}[1/5] Sistem güncelleniyor...${NC}"
apt update && apt upgrade -y

echo -e "${GREEN}[2/5] Ollama kuruluyor...${NC}"
curl -fsSL https://ollama.com/install.sh | sh

echo -e "${GREEN}[3/5] Mixtral modeli indiriliyor...${NC}"
ollama pull mixtral

mkdir -p /root/elitegpt && cd /root/elitegpt

echo -e "${GREEN}[4/5] Bellek dosyaları aktarılıyor...${NC}"
cp /root/elitegpt_pack/memory_*.json .

echo -e "${GREEN}[5/5] EliteGPT kurulumu tamamlandı. Komutu ver, kralım.${NC}"
